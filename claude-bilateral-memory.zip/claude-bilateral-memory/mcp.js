import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { ListToolsRequestSchema, CallToolRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import fs from "fs";
import os from "os";
import path from "path";

const MEMORY_FILE = path.join(os.homedir(), ".claude-shared-memory.json");

function loadMemory() {
  if (!fs.existsSync(MEMORY_FILE)) return {};
  return JSON.parse(fs.readFileSync(MEMORY_FILE, "utf-8"));
}

function saveMemory(data) {
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(data, null, 2));
}

const server = new Server(
  { name: "shared-memory", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "save_memory",
      description: "Save a key-value memory entry shared between Claude Code and Claude.ai",
      inputSchema: {
        type: "object",
        properties: {
          key: { type: "string", description: "The memory key/label" },
          value: { type: "string", description: "The memory value/content" }
        },
        required: ["key", "value"]
      }
    },
    {
      name: "get_memory",
      description: "Retrieve a memory entry by key",
      inputSchema: {
        type: "object",
        properties: {
          key: { type: "string", description: "The memory key to retrieve" }
        },
        required: ["key"]
      }
    },
    {
      name: "list_memories",
      description: "List all stored memory keys",
      inputSchema: {
        type: "object",
        properties: {}
      }
    },
    {
      name: "delete_memory",
      description: "Delete a memory entry by key",
      inputSchema: {
        type: "object",
        properties: {
          key: { type: "string", description: "The memory key to delete" }
        },
        required: ["key"]
      }
    }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const memory = loadMemory();
  const { name, arguments: args } = request.params;

  if (name === "save_memory") {
    memory[args.key] = {
      value: args.value,
      timestamp: new Date().toISOString(),
      source: "claude-code"
    };
    saveMemory(memory);
    return { content: [{ type: "text", text: `✅ Saved memory: "${args.key}"` }] };
  }

  if (name === "get_memory") {
    const entry = memory[args.key];
    if (!entry) return { content: [{ type: "text", text: `❌ No memory found for key: "${args.key}"` }] };
    return { content: [{ type: "text", text: `🧠 ${args.key}: ${entry.value}\n(saved: ${entry.timestamp})` }] };
  }

  if (name === "list_memories") {
    const keys = Object.keys(memory);
    if (keys.length === 0) return { content: [{ type: "text", text: "No memories stored yet." }] };
    const list = keys.map(k => `• ${k}: ${memory[k].value}`).join("\n");
    return { content: [{ type: "text", text: `🧠 Stored memories:\n${list}` }] };
  }

  if (name === "delete_memory") {
    if (!memory[args.key]) return { content: [{ type: "text", text: `❌ No memory found for key: "${args.key}"` }] };
    delete memory[args.key];
    saveMemory(memory);
    return { content: [{ type: "text", text: `🗑️ Deleted memory: "${args.key}"` }] };
  }
});

const transport = new StdioServerTransport();
await server.connect(transport);
