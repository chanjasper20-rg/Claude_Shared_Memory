import express from "express";
import fs from "fs";
import os from "os";
import path from "path";

const app = express();
app.use(express.json());

const MEMORY_FILE = path.join(os.homedir(), ".claude-shared-memory.json");
const PORT = process.env.PORT || 3001;

function loadMemory() {
  if (!fs.existsSync(MEMORY_FILE)) return {};
  return JSON.parse(fs.readFileSync(MEMORY_FILE, "utf-8"));
}

function saveMemory(data) {
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(data, null, 2));
}

// Get all memories
app.get("/memory", (req, res) => {
  res.json(loadMemory());
});

// Get a single memory by key
app.get("/memory/:key", (req, res) => {
  const memory = loadMemory();
  const entry = memory[req.params.key];
  if (!entry) return res.status(404).json({ error: "Memory not found" });
  res.json(entry);
});

// Save a memory
app.post("/memory", (req, res) => {
  const { key, value } = req.body;
  if (!key || !value) return res.status(400).json({ error: "key and value are required" });
  const memory = loadMemory();
  memory[key] = { value, timestamp: new Date().toISOString(), source: "claude-ai" };
  saveMemory(memory);
  res.json({ success: true, key, value });
});

// Delete a memory
app.delete("/memory/:key", (req, res) => {
  const memory = loadMemory();
  if (!memory[req.params.key]) return res.status(404).json({ error: "Memory not found" });
  delete memory[req.params.key];
  saveMemory(memory);
  res.json({ success: true, deleted: req.params.key });
});

app.listen(PORT, () => {
  console.log(`🧠 Memory API running on http://localhost:${PORT}`);
  console.log(`📁 Memory file: ${MEMORY_FILE}`);
  console.log(`\nEndpoints:`);
  console.log(`  GET    /memory         - List all memories`);
  console.log(`  GET    /memory/:key    - Get a specific memory`);
  console.log(`  POST   /memory         - Save a memory { key, value }`);
  console.log(`  DELETE /memory/:key    - Delete a memory`);
});
